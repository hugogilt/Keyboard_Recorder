// background.js
chrome.runtime.onInstalled.addListener(function() {
    console.log('Keyboard Capture Extension installed');
  });
  